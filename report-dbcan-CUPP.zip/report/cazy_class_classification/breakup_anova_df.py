import pandas as pd
from tqdm import tqdm

def breakup_df(inpath, outpath, tool_col = "Unnamed: 0"):
    df = pd.read_csv(inpath)
    new_rows = []
    for i in tqdm(range(len(df))):
        row = df.iloc[i]
        classifiers = row[tool_col]

        classifiers = classifiers.replace("dbCAN-sub", "sub")
        classifiers = classifiers.split("-")
        class_1 = classifiers[0].split(":")[0]
        class_2 = classifiers[1].split(":")[0]
        classifier_1 = ":".join(classifiers[0].split(":")[1:])
        classifier_2 = ":".join(classifiers[1].split(":")[1:])

        new_rows.append([
            class_1,
            class_2,
            classifier_1,
            classifier_2,
            row['diff'],
            row['lwr'],
            row['upr'],
            row['p adj'],
        ])

    new_df = pd.DataFrame(new_rows, columns=[
        'Class 1', 'Class 2',
        'Classifier 1', 'Classifier 2',
        'Mean Difference',
        'Lower 95% Confidence Interval',
        'Upper 95% Confidence Interval',
        'Adjusted P-value',
    ])
    new_df.to_csv(outpath, index=False)

    return new_df

def check_for_class_differences(df, outpath):
    tools = set(df['Classifier 1'])
    indexes = []
    for tool in tools:
        tool_filter = df[(df['Classifier 1']==tool) & (df['Classifier 2']==tool)]
        for i in range(len(tool_filter)):
            if str(tool_filter.iloc[i]['Adjusted P-value']).find('E') != -1:
                indexes.append(tool_filter.iloc[i].name)
            elif float(tool_filter.iloc[i]['Adjusted P-value']) < 0.05:
                indexes.append(tool_filter.iloc[i].name)
    print(f"Found {len(indexes)} differences between classes for the same tool")
    df.iloc[indexes].to_csv(outpath, index=False)#
    

def check_for_tool_differences(df, outpath):
    tools = set(df['Class 1'])
    indexes = []
    for tool in tools:
        tool_filter = df[(df['Class 1']==tool) & (df['Class 2']==tool)]
        for i in range(len(tool_filter)):
            if str(tool_filter.iloc[i]['Adjusted P-value']).find('E') != -1:
                indexes.append(tool_filter.iloc[i].name)
            elif float(tool_filter.iloc[i]['Adjusted P-value']) < 0.05:
                indexes.append(tool_filter.iloc[i].name)
    print(f"Found {len(indexes)} differences between tools for the same class")
    df.iloc[indexes].to_csv(outpath, index=False)

spec_df = breakup_df("class.spec.anova2.tukeyHSD.csv", "class.spec.anova2.tukeyHSD--brokenup.csv")
check_for_class_differences(spec_df, "class.spec.anova2.tukeyHSD--class-differences.csv")
check_for_tool_differences(spec_df, "class.spec.anova2.tukeyHSD--tool-differences.csv")

sens_df = breakup_df("class.sens.anova2.tukeyHSD.csv", "class.sens.anova2.tukeyHSD--brokenup.csv")
check_for_class_differences(sens_df, "class.sens.anova2.tukeyHSD--class-differences.csv")
check_for_tool_differences(sens_df, "class.sens.anova2.tukeyHSD--tool-differences.csv")

prec_df = breakup_df("class.prec.anova2.tukeyHSD.csv", "class.prec.anova2.tukeyHSD--brokenup.csv")
check_for_class_differences(prec_df, "class.prec.anova2.tukeyHSD--class-differences.csv")
check_for_tool_differences(prec_df, "class.prec.anova2.tukeyHSD--tool-differences.csv")

f1_df = breakup_df("class.f1.anova2.tukeyHSD.csv", "class.f1.anova2.tukeyHSD--brokenup.csv")
check_for_class_differences(f1_df, "class.f1.anova2.tukeyHSD--class-differences.csv")
check_for_tool_differences(f1_df, "class.f1.anova2.tukeyHSD--tool-differences.csv")

acc_df = breakup_df("class.acc.anova2.tukeyHSD.csv", "class.acc.anova2.tukeyHSD--brokenup.csv")
check_for_class_differences(acc_df, "class.acc.anova2.tukeyHSD--class-differences.csv")
check_for_tool_differences(acc_df, "class.acc.anova2.tukeyHSD--tool-differences.csv")

f1_df = breakup_df("/mnt/e/pyrewton_2023_eval/report/cazy_family_classification/fam.f1.aov2.tukeyHSD.csv", "/mnt/e/pyrewton_2023_eval/report/cazy_family_classification/fam.f1.aov2.tukeyHSD--brokenup.csv")
check_for_class_differences(f1_df, "/mnt/e/pyrewton_2023_eval/report/cazy_family_classification/fam.f1.aov2.tukeyHSD--class-differences.csv")
check_for_tool_differences(f1_df, "/mnt/e/pyrewton_2023_eval/report/cazy_family_classification/fam.f1.aov2.tukeyHSD--tool-differences.csv")

f1_df = breakup_df("/mnt/e/pyrewton_2023_eval/report/cazy_family_classification/fam.sens.aov2.tukeyHSD.csv", "/mnt/e/pyrewton_2023_eval/report/cazy_family_classification/fam.sens.aov2.tukeyHSD--brokenup.csv")
check_for_class_differences(f1_df, "/mnt/e/pyrewton_2023_eval/report/cazy_family_classification/fam.sens.aov2.tukeyHSD--class-differences.csv")
check_for_tool_differences(f1_df, "/mnt/e/pyrewton_2023_eval/report/cazy_family_classification/fam.sens.aov2.tukeyHSD--tool-differences.csv")

# ../report/cazy_family_classification/multilabel_classification/fam.ari.tukeyHSD.tax.csv
f1_df = breakup_df("/mnt/e/pyrewton_2023_eval/report/cazy_family_classification/multilabel_classification/fam.ari.tukeyHSD.tax.csv", "/mnt/e/pyrewton_2023_eval/report/cazy_family_classification/multilabel_classification/fam.ari.tukeyHSD--brokenup.csv")
check_for_class_differences(f1_df, "/mnt/e/pyrewton_2023_eval/report/cazy_family_classification/multilabel_classification/fam.ari.tukeyHSD--class-differences.csv")
check_for_tool_differences(f1_df, "/mnt/e/pyrewton_2023_eval/report/cazy_family_classification/multilabel_classification/fam.ari.tukeyHSD--tool-differences.csv")